# HealthMonitor
CS5453 Health Monitoring System Project

Flow:
Raspberry-pi -> AWS-IoT -> FrontEnd -> TwilioAPI 

Sensorend:
Run the script by using the command: “python3 finalAWS.py”


Frontend:
npm install appropriate libraries for reactjs. 


Backend:
Currently torndown as per mentor instruction. due to billing risk from AWS We have just the lambda code as reference.


GITHUB Repo: https://github.com/DevHSA/HealthMonitor